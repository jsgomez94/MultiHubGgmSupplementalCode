# facet_manual rejects some designs

    The `design` argument should be interpretable as a <matrix>.

---

    The `design` argument must be rectangular.

---

    The `design` argument cannot be NULL.

