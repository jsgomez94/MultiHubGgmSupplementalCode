# scale_colour_multi throws error when guide inappropriate

    ggh4x's author hasn't programmed this path yet.
    i Choose a legend or colourbar guide.

