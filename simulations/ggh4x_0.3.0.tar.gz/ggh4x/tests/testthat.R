library(testthat)
library(ggh4x)

test_check("ggh4x")
