
# `JGL` update
This quick 2018 update makes this old package (est. 2012) compatible with current CRAN requirements. 
No changes to the package's core functions have been made.